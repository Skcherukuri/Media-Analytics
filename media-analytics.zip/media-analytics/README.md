

Install Node 

Open Command Prompt and run the below command
 
node server.js


Navigate to the below url

http://localhost:9000/#/media
