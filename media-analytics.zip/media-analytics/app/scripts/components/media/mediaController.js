﻿(function () {

    'use strict';

    angular
        .module('media-analytics')
        .controller('mediaController', mediaController);

    mediaController.$inject = ['$scope', '$rootScope', 'commonServices'];

    function mediaController($scope, $rootScope, commonServices) {

        $scope.export = function () {
            commonServices.saveData($scope.data);
        };

        $scope.Like = function (actor) {
            actor.activity_likes = actor.activity_likes + 1;
        };

        $scope.Share = function (actor) {
            actor.activity_shares = actor.activity_shares + 1;
        };

        commonServices.getData().then(function (response) {
            $scope.data = response.data;
        }, function (response) {
        });
    };

})();
