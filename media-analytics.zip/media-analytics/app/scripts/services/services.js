﻿(function () {
    'use strict';

    angular
        .module('media-analytics')
        .service('commonServices', ['$http', commonServices]);

    function commonServices($http) {

        this.saveData = saveData;
        this.getData = getData;

        function saveData(data) {

             var filename = 'results.txt';

            if (typeof data === 'object') {
                data = JSON.stringify(data, undefined, 2);
            }

            var blob = new Blob([data], {type: 'text/json'});

            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                window.navigator.msSaveOrOpenBlob(blob, filename);
            }
            else{
                var e = document.createEvent('MouseEvents'),
                    a = document.createElement('a');
                a.download = filename;
                a.href = window.URL.createObjectURL(blob);
                a.dataset.downloadurl = ['text/json', a.download, a.href].join(':');
                e.initEvent('click', true, false, window,
                    0, 0, 0, 0, 0, false, false, false, false, 0, null);
                a.dispatchEvent(e);
            }
        }

        function getData() {
            return $http.get('https://nuvi-challenge.herokuapp.com/activities');
        }
    }
})();