﻿'use strict';


var mediaAnalytics = angular.module('media-analytics', [
                                          'ngRoute' ])
.config(function ($routeProvider) {
    $routeProvider
      .when('/media', {
          templateUrl: 'app/scripts/components/media/media.html',
          controller: 'mediaController'
      })
      .otherwise({
          redirectTo: '/media'
      });
})
.run(function ($browser ) {

    $browser.baseHref = function () {
        return "/media";
    };

});
