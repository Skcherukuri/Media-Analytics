﻿var express = require('express');
var Server = express();
Server.use(express.static(__dirname));
Server.use(express.static(__dirname + '/app'));

var port = 9000;

Server.listen(port, function () {
    console.log('Server listening on port' + port);
});
